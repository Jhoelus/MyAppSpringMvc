function peticionAjax(urlTxt){
	$.ajax({
		url:urlTxt,
		type:'GET',
		dataType:"text",		
		success: function(data){
			$('#result').html(data);
		},error: function(xhr,ajaxOptions,thrownError){
			$('#result').html('Error'+xhr.status+":"+thrownError+".");
		}
	});
}

function peticionAjaxP(urlTxt){
	$.ajax({
		url:urlTxt,
		type:'POST',
		data: $("#form").serialize(),
		success: function(data){
			$('#result').html(data);
		},error: function(xhr,ajaxOptions,thrownError){
			$('#result').html('Error'+xhr.status+":"+thrownError+".");
		}
	});
}

function chkSoluClick(){
   if( $("#chkSolu").is(':checked') ){ 
	   $("#panelBodySolTempo").css("display","block");
   }else{
	   $("#panelBodySolTempo").css("display","none");
   }
   cargarCalendar();
}

function cargarCalendar(){
	$("#fechaCorreccionTemporal").datepicker({
		format: 'dd/MM/yyyy'
    });

	$("#fechaEstimadaSoluDefinitiva").datepicker({
		format: 'dd/mm/yyyy'
	});
}

function initInputTypeCalendar(idInput){
	$("#"+idInput).datepicker({
		format: 'dd/mm/yyyy'
	});
}