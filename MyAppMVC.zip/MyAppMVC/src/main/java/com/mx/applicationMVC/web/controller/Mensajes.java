package com.mx.applicationMVC.web.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mx.applicationMVC.dto.MensajeDTO;

@Controller
public class Mensajes {
	
	@RequestMapping(value="/index.htm")
    public String handleRequest(Model model) {
        return "index";
    }

	@ModelAttribute("msg")
	public  Map<String, Object> initMensajes(){
		
		List<MensajeDTO> listaMensajes = new ArrayList<MensajeDTO>();
		
		MensajeDTO msg1 = new MensajeDTO();
		MensajeDTO msg2 = new MensajeDTO();
		MensajeDTO msg3 = new MensajeDTO();
		MensajeDTO msg4 = new MensajeDTO();
		MensajeDTO msg5 = new MensajeDTO();

		msg1.setAsunto("Asunto Uno");
		msg2.setAsunto("Asunto PRUEBA");
		msg3.setAsunto("Asunto PINO");
		msg4.setAsunto("Asunto PATA");
		msg5.setAsunto("Asunto Roto");

		msg1.setRemitente("Animal");
		msg2.setRemitente("Tarzan");
		msg3.setRemitente("Changui");
		msg4.setRemitente("Bananin");
		msg5.setRemitente("Rotin");

		msg1.setTime("5 minutos");
		msg2.setTime("2 horas");
		msg3.setTime("Hoy");
		msg4.setTime("Ayer");
		msg5.setTime("Abril");

		listaMensajes.add(msg1);
		listaMensajes.add(msg2);
		listaMensajes.add(msg3);
		listaMensajes.add(msg4);
		listaMensajes.add(msg5);
		
        int numMensajes = listaMensajes.size();
        
        Map<String, Object> myModel = new HashMap<String, Object>();
        

        myModel.put("numMensajes", numMensajes);
        myModel.put("mensajes", listaMensajes);
        
		return myModel;
	}
}
