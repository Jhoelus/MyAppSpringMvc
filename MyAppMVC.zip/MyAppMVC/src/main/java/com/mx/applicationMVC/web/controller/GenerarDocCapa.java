package com.mx.applicationMVC.web.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mx.applicationMVC.dto.ProductosCapaDTO;
import com.mx.applicationMVC.web.model.documentos.tiposDocs.CapaDocModel;

@Controller
@RequestMapping("/crearDocCapa")
public class GenerarDocCapa {
	
	@RequestMapping(method= RequestMethod.GET)
	public String init(Model model) throws ServletException{
		CapaDocModel capa = new CapaDocModel();
		model.addAttribute("formCrearDocCapa",capa);
		model.addAttribute("nameDoc","Carta de aceptaci�n de la propuesta");
		return "crearDocCapa";
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public String methodPost() throws ServletException{
		/*
		 *	Con el Id de requerimiento sacar de BD
		 *		* idEstimacion 
		 *		* nombreRequerimiento
		 *
		 *	Sacar de la sesion el responsable de la version
		 *
		 *	Sacar el nombre del proyecto de BD ya que tiene que ser el mismo que el de la propuesta
		 *
		 *	
		 * */
		return "";
	}
	
	@ModelAttribute(value="productos")
	public List<ProductosCapaDTO> iniTabla(){
		ProductosCapaDTO productosCapaDTO1 = new ProductosCapaDTO();
		productosCapaDTO1.setDescripcion("product 1");
		productosCapaDTO1.setFormatoHerramienta("Herramienta 1");
		productosCapaDTO1.setFechaCompromiso(new Date().toString());
		
		ProductosCapaDTO productosCapaDTO2 = new ProductosCapaDTO();
		productosCapaDTO2.setDescripcion("product 2");
		productosCapaDTO2.setFormatoHerramienta("Herramienta 2");
		productosCapaDTO2.setFechaCompromiso(new Date().toString());
		
		ProductosCapaDTO productosCapaDTO3 = new ProductosCapaDTO();
		productosCapaDTO3.setDescripcion("product 3");
		productosCapaDTO3.setFormatoHerramienta("Herramienta 3");
		productosCapaDTO3.setFechaCompromiso(new Date().toString());
		
		ProductosCapaDTO productosCapaDTO4 = new ProductosCapaDTO();
		productosCapaDTO4.setDescripcion("product 4");
		productosCapaDTO4.setFormatoHerramienta("Herramienta 4");
		productosCapaDTO4.setFechaCompromiso(new Date().toString());
		
		 List<ProductosCapaDTO> prod = new ArrayList<>();
		 prod.add(productosCapaDTO1);
		 prod.add(productosCapaDTO2);
		 prod.add(productosCapaDTO3);
		 prod.add(productosCapaDTO4);
		 
		 return prod;
	}
	
	@ModelAttribute(value="listaDescProduct")
	public List<String> iniListaDesProduc(){
		List<String> listadesPro = new ArrayList<>();
		listadesPro.add("Dise�o de Componentes");
		listadesPro.add("Documento de Pruebas");
		listadesPro.add("Manual de Compilaci�n");
		listadesPro.add("Manual de Instalaci�n");
		listadesPro.add("Car�tula (RDL)");
		listadesPro.add("Manual de Instalaci�n");
		return listadesPro;
	}
	
	@ModelAttribute(value="listFormatoHerramientas")
	public List<String> iniListaHerramietas(){
		List<String> listaHerra = new ArrayList<>();
		listaHerra.add("SharePoint");
		listaHerra.add("Monitor");
		listaHerra.add("Harvest");
		listaHerra.add("Harvest/Monitor");

		return listaHerra;
	}
	
}
