package com.mx.applicationMVC.comun;

public final class ConstantaesAplicativo {
	
	private ConstantaesAplicativo(){
		
	}
}
