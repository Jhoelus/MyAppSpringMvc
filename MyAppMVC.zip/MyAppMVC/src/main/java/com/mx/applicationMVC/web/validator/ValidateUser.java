package com.mx.applicationMVC.web.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.mx.applicationMVC.web.model.UsuarioModel;

public class ValidateUser implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		return UsuarioModel.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		UsuarioModel usuario = (UsuarioModel) target;
		
		ValidationUtils.rejectIfEmpty(errors, "usuario", "field.usuario.invalid","El usuario no puede ser nulo");
		
		if(usuario.getComentarios().contains("joel")){
			//1.Campo 2.Nombre del Error 3.Mensaje devuelto del error
			errors.rejectValue("comentarios","field.comentarios.invalid","El comentario no es valido");
		}
		
		if(!usuario.getPass().equals(usuario.getConfirmarPass())){
			errors.rejectValue("confirmarPass", "field.confirmarPass.invalid","La password no coincide");
		}
		
		if(usuario.getGustos().length == 0){
			errors.rejectValue("gustos", "field.gustos.invalid","Seleccione por lo menos un gusto");
		}
	}

}
