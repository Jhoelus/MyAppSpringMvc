package com.mx.applicationMVC.web.model;

import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

public class UsuarioModel {

	private String usuario;
	
	@Email
	private String correoElectro;
	
	@Size(min=3,max=7,message="La password no cumple con el tama�o correcto")
	private String pass;
	private String confirmarPass;
	
	@NotBlank(message="El sexo no puede ser nulo")
	private String sexo;
	
	@NotBlank(message="El pais no puede ser nulo")
	private String pais;
	
	@Min(value=18,message="No se puede registrar un menor de edad")
	private int edad;
	
	@NotBlank(message="Escriba un comentario")
	private String comentarios;
	
	private String[] gustos;
	
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getCorreoElectro() {
		return correoElectro;
	}
	public void setCorreoElectro(String correoElectro) {
		this.correoElectro = correoElectro;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getConfirmarPass() {
		return confirmarPass;
	}
	public void setConfirmarPass(String confirmarPass) {
		this.confirmarPass = confirmarPass;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	public String getComentarios() {
		return comentarios;
	}
	public void setComentarios(String comentarios) {
		this.comentarios = comentarios;
	}
	public String[] getGustos() {
		return gustos;
	}
	public void setGustos(String[] gustos) {
		this.gustos = gustos;
	}
	
	@Override
	public String toString() {
		StringBuilder user = new StringBuilder();
		user.append("Usuario: " + usuario + "\n");
		user.append("Correo Electronico:" +correoElectro+ "\n");
		user.append("Pwd: " + pass+ "\n");
		user.append("Confirmar pwd:" + confirmarPass+ "\n");
		user.append("Pais: " + pais+ "\n");
		user.append("Sexo: " + sexo+ "\n");
		user.append("Edad: " + edad+ "\n");
		user.append("Comentarios: " + comentarios+ "\n");
		user.append("Gustos: ");
		for(String s : gustos){
			if(s.equals(gustos[gustos.length-1])){
				user.append(s+".");
			}else{
				user.append(s + ",");
			}
		}
		
		return user.toString();
		
	} 
}
