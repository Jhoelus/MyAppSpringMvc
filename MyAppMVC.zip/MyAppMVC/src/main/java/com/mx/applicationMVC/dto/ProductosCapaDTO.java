package com.mx.applicationMVC.dto;

public class ProductosCapaDTO {

	private String nombreProdArtefacto;
	private String descripcion;
	private String formatoHerramienta;
	private String fechaCompromiso;
	
	public String getNombreProducto() {
		return nombreProdArtefacto;
	}
	public void setNombreProducto(String nombreProducto) {
		this.nombreProdArtefacto = nombreProducto;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getFormatoHerramienta() {
		return formatoHerramienta;
	}
	public void setFormatoHerramienta(String formatoHerramienta) {
		this.formatoHerramienta = formatoHerramienta;
	}
	public String getFechaCompromiso() {
		return fechaCompromiso;
	}
	public void setFechaCompromiso(String fechaCompromiso) {
		this.fechaCompromiso = fechaCompromiso;
	}	
}
