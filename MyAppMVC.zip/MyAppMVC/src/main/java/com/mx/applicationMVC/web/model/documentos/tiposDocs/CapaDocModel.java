package com.mx.applicationMVC.web.model.documentos.tiposDocs;

import com.mx.applicationMVC.web.model.documentos.commons.Documento;

public class CapaDocModel extends Documento{
	
	private String fechaEntregaDocumento;
	private String responsableSofttek;
	private String puesto;
	
	private String nombreProyecto;
	
	private String nameProducto;
	private String formatoHerramienta;
	
	private String fechaCompromiso;
	
	public String getFechaEntregaDocumento() {
		return fechaEntregaDocumento;
	}
	public void setFechaEntregaDocumento(String fechaEntregaDocumento) {
		this.fechaEntregaDocumento = fechaEntregaDocumento;
	}
	public String getResponsableSofttek() {
		return responsableSofttek;
	}
	public void setResponsableSofttek(String responsableSofttek) {
		this.responsableSofttek = responsableSofttek;
	}
	public String getPuesto() {
		return puesto;
	}
	public void setPuesto(String puesto) {
		this.puesto = puesto;
	}
	public String getNombreProyecto() {
		return nombreProyecto;
	}
	public void setNombreProyecto(String nombreProyecto) {
		this.nombreProyecto = nombreProyecto;
	}
	
	public String getFechaCompromiso() {
		return fechaCompromiso;
	}
	public void setFechaCompromiso(String fechaCompromiso) {
		this.fechaCompromiso = fechaCompromiso;
	}
	public String getNameProducto() {
		return nameProducto;
	}
	public void setNameProducto(String nameProducto) {
		this.nameProducto = nameProducto;
	}
	public String getFormatoHerramienta() {
		return formatoHerramienta;
	}
	public void setFormatoHerramienta(String formatoHerramienta) {
		this.formatoHerramienta = formatoHerramienta;
	}
	
	
 }
