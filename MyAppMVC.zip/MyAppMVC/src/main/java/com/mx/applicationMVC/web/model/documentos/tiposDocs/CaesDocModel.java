package com.mx.applicationMVC.web.model.documentos.tiposDocs;

import com.mx.applicationMVC.web.model.documentos.commons.Documento;

public class CaesDocModel extends Documento {

}
