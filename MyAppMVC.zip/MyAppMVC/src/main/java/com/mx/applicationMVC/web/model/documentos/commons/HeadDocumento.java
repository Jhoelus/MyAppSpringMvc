package com.mx.applicationMVC.web.model.documentos.commons;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.validator.constraints.NotBlank;

public class HeadDocumento {

	/*Tabla de versiones*/
	@NotBlank(message="Ingresa el numero de version")
	private String numeroVersion;
	
	@NotBlank(message="Ingresa una breve descripcion del cambio")
	private String descripcionDelCambio;
	
	@NotBlank(message="Sacar el Responsable de la sesion")
	private String responsableVersion;
	
	@NotBlank(message="Sacar la fecha en el momento que se crea el archivo")
	private String fecha;
	
	public String getNumeroVersion() {
		return numeroVersion;
	}
	public void setNumeroVersion(String version) {
		this.numeroVersion = version;
	}
	public String getDescripcionDelCambio() {
		return descripcionDelCambio;
	}
	public void setDescripcionDelCambio(String descripcionDelCambio) {
		this.descripcionDelCambio = descripcionDelCambio;
	}
	public String getResponsableVersion() {
		return responsableVersion;
	}
	public void setResponsableVersion(String responsableVersion) {
		this.responsableVersion = responsableVersion;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = new SimpleDateFormat("dd/MM/YYYY").format(fecha);
	}
}
