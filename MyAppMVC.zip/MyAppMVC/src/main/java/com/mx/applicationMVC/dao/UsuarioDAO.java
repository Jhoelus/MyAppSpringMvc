package com.mx.applicationMVC.dao;

public interface UsuarioDAO {

}
