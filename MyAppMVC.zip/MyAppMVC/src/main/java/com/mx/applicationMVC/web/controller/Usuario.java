package com.mx.applicationMVC.web.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mx.applicationMVC.web.model.UsuarioModel;
import com.mx.applicationMVC.web.validator.ValidateUser;

@Controller
@RequestMapping(value="/user.htm")
public class Usuario {
	
//	@InitBinder
//	 protected void initBinder(WebDataBinder binder) {
//	 	binder.setValidator(new ValidateUser());
//	 }
	
	@RequestMapping(method= RequestMethod.GET)
	public String init(Model model){
		model.addAttribute("usuario",new UsuarioModel());
		model.addAttribute("view","user");
		return "index";
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public String enviar(@ModelAttribute("usuario") @Valid UsuarioModel user,BindingResult result,Model model){
		
		new ValidateUser().validate(user, result);
	
		if(result.hasErrors()){
			model.addAttribute("view","user");
			return "index";
		}
		
		model.addAttribute("view","user");
		return "index";
	}
	
	@ModelAttribute("listPaises")
	public Map<String,String> initPaises(){
		Map<String,String> listPaises = new LinkedHashMap<String,String>();
		listPaises.put("MX", "MEXICO");
		listPaises.put("FI", "FINLAND");
		listPaises.put("DE", "GERMANY");
		listPaises.put("JE", "JAMAICA");
		listPaises.put("UY", "URUGUAY");
		return listPaises;
	}
	
	@ModelAttribute("listaGustos")
	public List<String> initGustos(){
		List<String> listaGustos = new ArrayList<String>();
		listaGustos.add("DOCUMENTALES");
		listaGustos.add("FUTBOL");
		listaGustos.add("BOLICHE");
		return listaGustos;
	}
}
