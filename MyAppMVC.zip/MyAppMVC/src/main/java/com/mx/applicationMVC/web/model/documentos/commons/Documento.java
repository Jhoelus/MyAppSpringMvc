package com.mx.applicationMVC.web.model.documentos.commons;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;

public class Documento {
	
	@Autowired
	@NotNull(message = "No puede ser nulo el food")
	@Valid
	FootDocumento footDoc;
	
	@Autowired
	@NotNull(message = "No puede ser nulo el head")
	@Valid
	HeadDocumento headDoc;
	
	private String nombreArquetipo;
	private String idRequerimiento;
	private String idEstimacion;
	private String nombreRequerimiento;
	
	public FootDocumento getFootDoc() {
		return footDoc;
	}

	public void setFootDoc(FootDocumento footDoc) {
		this.footDoc = footDoc;
	}

	public HeadDocumento getHeadDoc() {
		return headDoc;
	}

	public void setHeadDoc(HeadDocumento headDoc) {
		this.headDoc = headDoc;
	}

	public String getNombreArquetipo() {
		return nombreArquetipo;
	}

	public void setNombreArquetipo(String nombreArquetipo) {
		this.nombreArquetipo = nombreArquetipo;
	}

	public String getIdRequerimiento() {
		return idRequerimiento;
	}

	public void setIdRequerimiento(String idRequerimiento) {
		this.idRequerimiento = idRequerimiento;
	}

	public String getIdEstimacion() {
		return idEstimacion;
	}

	public void setIdEstimacion(String idEstimacion) {
		this.idEstimacion = idEstimacion;
	}

	public String getNombreRequerimiento() {
		return nombreRequerimiento;
	}

	public void setNombreRequerimiento(String nombreRequerimiento) {
		this.nombreRequerimiento = nombreRequerimiento;
	}
}
