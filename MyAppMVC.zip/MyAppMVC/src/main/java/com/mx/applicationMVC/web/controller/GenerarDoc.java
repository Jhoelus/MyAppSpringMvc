package com.mx.applicationMVC.web.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mx.applicationMVC.web.model.documentos.tiposDocs.DtsDocModel;

@Controller
@RequestMapping(value="/crearDocumento.htm")
public class GenerarDoc {
	
	@RequestMapping(method = RequestMethod.GET)
	public String init(Model model) throws ServletException {
		
		DtsDocModel dtsDocModel = new DtsDocModel();
		model.addAttribute("nameDoc","Dictamen tecnico de solucion");
		model.addAttribute("dtsDoc",dtsDocModel);
		return "crearDocumento";
    }
	
	@RequestMapping(method = RequestMethod.POST)
	public  String onSubmit(@ModelAttribute("dtsDoc") @Valid DtsDocModel dtsDoc, BindingResult result,Model model) throws ServletException {

//		System.out.println(dtsDoc);
//		System.out.println(model.toString());

		if (result.hasErrors()) {
			return "crearDocumento";
		}
		
		dtsDoc.getHeadDoc().setResponsableVersion("Sacar de la session");
		dtsDoc.setNombreArquetipo("CEEC154531Ejemplo");
		dtsDoc.setPaquetesDeLiberacion(dtsDoc.getNombreArquetipo());
		dtsDoc.getHeadDoc().setFecha(new Date());
		return "index";
	}
	
	@ModelAttribute("listaAplicaciones")
	public Map<String,String> initListaDoc(){
		Map<String,String> listaDoc = new LinkedHashMap<String,String>();
		listaDoc.put("PPS","Pago Provisional Simplificado");
		listaDoc.put("INAMI","Declaraci�n de Pasajeros y Excedente de Franquicia");
		listaDoc.put("RFS","Registro Fiscal Simplificado");
		listaDoc.put("PDC","Relaci�n de Contribuyentes Incumplidos");
		listaDoc.put("SAIMYP","Sistema Automatizado Integral de Marbetes y Precintos");
		listaDoc.put("SRIF","Simulador RIF");
	
		return listaDoc;
	}
	
	@ModelAttribute("listaResponsablesStk")
	public List<String> listaResponsSfk(){
		List<String> lstResStk = new ArrayList<String>();
		
		lstResStk.add("Responsable STK 1");
		lstResStk.add("Responsable STK 2");
		lstResStk.add("Responsable STK 3");
		
		return lstResStk;
	}
	
	@ModelAttribute("listaResponsablesSat")
	public List<String> listaResponsSat(){
		List<String> lstResSat = new ArrayList<String>();
		
		lstResSat.add("Responsable SAT 1 ...");
		lstResSat.add("Responsable SAT 2 ...");
		lstResSat.add("Responsable SAT 3 ...");
		
		return lstResSat;
	}
}
