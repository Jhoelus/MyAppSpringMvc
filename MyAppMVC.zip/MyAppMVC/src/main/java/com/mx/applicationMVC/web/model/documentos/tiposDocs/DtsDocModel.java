package com.mx.applicationMVC.web.model.documentos.tiposDocs;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.validator.constraints.NotBlank;

import com.mx.applicationMVC.web.model.documentos.commons.Documento;

public class DtsDocModel extends Documento{
	
	private SimpleDateFormat formatear = new SimpleDateFormat("dd/MM/YYYY");

	@NotBlank(message="Error Debe ingresar un incidente valido")
	private String idIncidente;
	
	@NotBlank(message="Error Seleccione un Aplicativo valido")
	private String nombreAplicativo;
	
	private boolean solTempo;
	
	/*Tabla de incidente**/
	@NotBlank(message="Error Seleccione un Responsable SFTk valido")
	private String responsableStk;
	@NotBlank(message="Error Seleccione un Responsable SAT valido")
	private String responsableSat;
	
	/* Descripcion Analisis */
	@NotBlank(message="Describa el problema")
	private String identificacionProblema;
	@NotBlank(message="Describa el Analisis")
	private String analisisCausa;
	private String fechaAnalisis;
	
	/* Solucion Temporal */
	private String solucionTemporal;
	private String fechaCorreccionTemporal;
	private String justificacionSoluTempo;
	private String riesgosSoluTempo; 
	private String fechaEstimadaSoluDefinitiva; 
	
	/*foot*/
	@NotBlank(message="Describa la solucion definitiva")
	private String solucionDefinitiva;
	
	private String paquetesDeLiberacion;
	
	
	public String getIdIncidente() {
		return idIncidente;
	}
	public void setIdIncidente(String idIncidente) {
		this.idIncidente = idIncidente;
	}
	public String getNombreAplicativo() {
		return nombreAplicativo;
	}
	public void setNombreAplicativo(String nombreAplicacion) {
		this.nombreAplicativo = nombreAplicacion;
	}
	public String getResponsableStk() {
		return responsableStk;
	}
	public void setResponsableStk(String responsableStk) {
		this.responsableStk = responsableStk;
	}
	public String getResponsableSat() {
		return responsableSat;
	}
	public void setResponsableSat(String responsableSat) {
		this.responsableSat = responsableSat;
	}
	public String getIdentificacionProblema() {
		return identificacionProblema;
	}
	public void setIdentificacionProblema(String identificacionProblema) {
		this.identificacionProblema = identificacionProblema;
	}
	public String getAnalisisCausa() {
		return analisisCausa;
	}
	public void setAnalisisCausa(String analisisCausa) {
		if(analisisCausa!=null && !analisisCausa.isEmpty()){
			this.analisisCausa = analisisCausa;
			setFechaAnalisis(formatear.format(new Date()));
		}
	}
	public String getFechaAnalisis() {
		return fechaAnalisis;
	}
	public void setFechaAnalisis(String fechaAnalisis) {
		this.fechaAnalisis = fechaAnalisis;
	}
	public String getSolucionTemporal() {
		return solucionTemporal;
	}
	public void setSolucionTemporal(String solucionTemporal) {
		this.solucionTemporal = solucionTemporal;
	}
	public String getFechaCorreccionTemporal() {
		return fechaCorreccionTemporal;
	}
	public void setFechaCorreccionTemporal(String fechaCorreccionTemporal) {
		this.fechaCorreccionTemporal = fechaCorreccionTemporal;
	}
	public String getJustificacionSoluTempo() {
		return justificacionSoluTempo;
	}
	public void setJustificacionSoluTempo(String justificacionSoluTempo) {
		this.justificacionSoluTempo = justificacionSoluTempo;
	}
	public String getRiesgosSoluTempo() {
		return riesgosSoluTempo;
	}
	public void setRiesgosSoluTempo(String riesgosSoluTempo) {
		this.riesgosSoluTempo = riesgosSoluTempo;
	}
	public String getFechaEstimadaSoluDefinitiva() {
		return fechaEstimadaSoluDefinitiva;
	}
	public void setFechaEstimadaSoluDefinitiva(String fechaEstimadaSoluDefinitiva) {
		this.fechaEstimadaSoluDefinitiva = fechaEstimadaSoluDefinitiva;
	}
	public String getSolucionDefinitiva() {
		return solucionDefinitiva;
	}
	public void setSolucionDefinitiva(String solucionDefinitiva) {
		this.solucionDefinitiva = solucionDefinitiva;
	}
	public String getPaquetesDeLiberacion() {
		return paquetesDeLiberacion;
	}
	public void setPaquetesDeLiberacion(String paquetesDeLiberacion) {
		this.paquetesDeLiberacion = paquetesDeLiberacion;
	}
	public boolean isSolTempo() {
		return solTempo;
	}
	public void setSolTempo(boolean solTempo) {
		this.solTempo = solTempo;
	}
	
	@Override
	public String toString() {
		StringBuilder st = new StringBuilder();
		
		st.append("Id incidente: " + idIncidente+"\n");
		st.append("Aplicativo:" + nombreAplicativo+"\n");
		st.append("Solucion temporal: " + solTempo+"\n");
		st.append("Responsable SFTK: "+ responsableStk+"\n");
		st.append("Responsable SAT: "+ responsableSat+"\n");
		
		st.append("Problema: "+ identificacionProblema+"\n");
		st.append("Analisis Causa" + analisisCausa+"\n");
		st.append("FEcha de analisis: " + fechaAnalisis+"\n");
		
		st.append("Solucion Tmporal: " + solucionTemporal+"\n");
		st.append("FEcha sol temporal: "+ fechaCorreccionTemporal+"\n");
		st.append("Justificacion sol tempo: " + justificacionSoluTempo+"\n");
		st.append("Riesgo de la sol tempo: " + riesgosSoluTempo+"\n");
		st.append("Fecha de sol tempo: " + fechaEstimadaSoluDefinitiva+"\n");
		
		st.append("Solucion definitiva:" + solucionDefinitiva+"\n");
		st.append("paquetes de liberacion: " + paquetesDeLiberacion+"\n");
		
		return st.toString();

	}
}
