package com.mx.applicationMVC.web.model.documentos.commons;

public class FootDocumento {

}
